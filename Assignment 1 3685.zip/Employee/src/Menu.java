import java.util.Scanner;
class Menu {
    public static void main(String[] args){
        EmployeeList info=new EmployeeList();
        Scanner Input= new Scanner(System.in);
        int choice;
        System.out.println("Enter Options");
        System.out.println("1 to enter new employee data");
        System.out.println("2 to display all results");
        System.out.println("3 to sort Employee by Id and display all results");
        System.out.println("4 to search Employee by Id and display result");
        choice=Input.nextInt();

        }
    }
}
