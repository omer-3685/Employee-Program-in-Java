import java.util.Scanner;
class Employee {
    private String Name, Designation, Department;
    private int Id, Age;

    public Employee(String emp_Name, String emp_Designate, String emp_Dept, int emp_Id, int emp_Age) {
        this.Name = emp_Name;
        this.Designation = emp_Designate;
        this.Department = emp_Dept;
        this.Id = emp_Id;
        this.Age = emp_Age;
    }

    public Employee() {

    }

    public String getName() {
        return Name;
    }

    public String getDesignation() {
        return Designation;
    }
    public String getDepartment() {
        return Department;
    }
    public int getId() {
        return Id;
    }
    public int getAge() {
        return Age;
    }
    public void setName(String name) {
        Name = name;
    }

    public void setDesignation(String designation) {
        Designation = designation;
    }



    public void setDepartment(String department) {
        Department = department;
    }



    public void setId(int id) {
        Id = id;
    }



    public void setAge(int age) {
        Age = age;
    }
    public String toString(){
        return(""+Id+","+Name+","+Department+","+Designation+","+Age+"");
    }

    }

