class EmployeeList extends Employee{

    final int size = 20;
    Employee info[] = new Employee[size];


    public EmployeeList() {
        for (int i = 0; i < 20; i++) {
            info[i] = new Employee();
        }

    }

    public void insertion(int i, int id, String name, String designation, int age, String department) {
        if (i >= 0 && i <= 19) {
            info[i].setId(id);
            info[i].setName(name);
            info[i].setDesignation(designation);
            info[i].setDepartment(department);
            info[i].setAge(age);

        } else {
            System.out.println("Data is full");
        }


    }

    public void infoSort() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size - 1; j++) {
                if (info[j].getId() > info[j + 1].getId()) {
                    Employee temp = new Employee();
                    temp = info[j];
                    info[j] = info[j + 1];
                    info[j + 1] = temp;
                }
            }
        }
        for (int i = 0; i < size; i++)
            System.out.println(info[i].toString());
    }

    public void search() {
        for (int i = 0; i < size; i++) {
            if (info[i].getId() == info[size].getId()) {
                System.out.println("Record found" + info[i].toString());
            }
            else{
                System.out.println("Record Not Found");
            }
        }
    }
}